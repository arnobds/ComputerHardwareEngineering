#include <pic32mx.h>

int main() {
    init(); /* Do any lab-specific initialization */

	while( 1 )
	{
    work(); /* Do lab-specific things again and again */
	}
	return 0;
}

